<?php $page= "about";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">ABOUT US</h1>
                        <p class="mt-3 small">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">HOME</a> 
                            <span class="text-white small"> / &nbsp; ABOUT US</span>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7 py-4 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 mt-5">
                        <img class="w-100 left-reveal" src="assets/image/6.jpg">
                    </div>
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <h6 class="txt-grad left-reveal">ABOUT US</h6>
                        <h2 class="right-reveal">Learn New Skills to go ahead for Your Career</h2>
                        <p class="left-reveal">Our vision at Nerdclasses is to reimagine and evolve the way teaching and learning that had been happening for decades. By combining quality trainers, engaging content and superior technology we are able to create a superior learning experience for attendees and aid in their outcome improvement, which is unlike any offline experience.<br><br>

NerdClasses empowers anyone who wants to train in the company by providing the required platform. The idea behind the strategy is to create a world class skill learning experience and develop a tech enabled system .</p>
                        <p>
                            <a class="btn btn btns9 rounded-pill px-5 py-3 ml-2 mt-4" href="#">Learn More</a> 
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section4 -->
        <section class="section4 bg-sec4 py-5 mt-5">
            <div class="container py-5">
                <div class="row justify-content-center text-white align-items-center">
                    <div class="col-12 col-lg-7">
                        <h6 class="txt-grad left-reveal">CONTACT US NOW IF YOU HAVE ANY QUESTION</h6>
                        <h2 class="left-reveal">Get in Touch with us so Easy.</h2>
                        <p class="mt-4 text-light left-reveal">Lorem ipsum dolor sit amet, adipisicing elit. Ratione provident omnis iusto, veniam
                            libero accusamus esse ab, enim
                            temporibus.</p>
                        <div class="d-md-flex p-3 bg-white rounded-pill mt-4">
                            <div class="border rounded-pill mt-md-0 mt-3 pb-5 form-control d-flex">
                                <i class="fa fa-home fa-lg text-gold mt-2 pt-1 pl-2"></i>
                                <input type="text" class="form-control border-0 shadow-none">
                            </div>
                            <div class="input-group-append ml-sm-3">
                                <button class="btn btn btns8 mx-auto d-block mt-md-0 mt-3 rounded-pill px-5 py-3" type="button">Subscribe</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5"></div>
                </div>
            </div>
        </section>


        <!-- section3 -->
        <section class="section3 py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-5 mt-5 bottom-reveal">
                        <img class="w-100" src="assets/image/digital-5.png">
                    </div>
                    <div class="col-12 col-md-7 pl-md-5 mt-5">
                        <h6 class="txt-grad right-reveal">WORKING COSELY TOGEATHER</h6>
                        <h2 class="left-reveal">Our platform takes away the hard process of creating your website</h2>
                        <p class="mt-4 right-reveal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit eum illum tempora? Ducimus eum culpa voluptates
                        dolorem dolorum et sit nisi, mollitia animi porro fuga sequi, molestias repellat excepturi nobis eum culpa voluptates
                        dolorem dolorum et.</p>
                        
                        <div class="d-md-flex">
                            <div class="mt-4 left-reveal">
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>Managed Sucre Backups</span></p>
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>Advanced Caching</span></p>
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>Unlimited Applications</span></p>
                            </div>
                            <div class="mt-4 ml-md-5 right-reveal">
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>PHP 7 Ready Servers</span></p>
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>24/7 Expert Support</span></p>
                                <p class="mb-1"><i class="fa fa-check-circle fa-lg mr-3 text-blue"></i><span>Optimized Stack</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section5 -->
        <section class="section5 mt-4">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">OUR FEATURES</h6>
                        <h2 class="left-reveal right-reveal">Why Choose Us</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row mb-3 mt-3">
                    <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg hvr-float-shadow p-4">
                            <img class="" src="assets/image/1.svg">
                            <div class="mt-4">
                                <h5 class="text-body font-weight-bold h6">Go Live in Minutes</h5>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                    ac cu msan ut, posuere sit Lorem ipsum qu.</p>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-12 col-md-6 col-lg-4 mt-4 bottom-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg hvr-float-shadow p-4">
                            <img class="" src="assets/image/2.svg">
                            <div class="mt-4">
                                <h5 class="text-body font-weight-bold h6">Manage like A Pro</h5>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                    ac cu msan ut, posuere sit Lorem ipsum qu.</p>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-12 col-md-6 col-lg-4 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg hvr-float-shadow p-4">
                            <img class="" src="assets/image/3.svg">
                            <div class="mt-4">
                                <h5 class="text-body font-weight-bold h6">Scale to Success</h5>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                    ac cu msan ut, posuere sit Lorem ipsum qu.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section9 -->
        <section class="section9 mt-5">
            <div class="container ">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad2 left-reveal">Our Creative Team</h6>
                        <h2 class="right-reveal">Our Awesome Team</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan
                            nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row mb-3 mt-3 text-center">
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member1.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Randy Crishen</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Company CEO</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member2.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Monica Ashker</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Web Designer</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member1.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Tollay Ramzomi</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Web Developer</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member2.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Jacke Wilson</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Marketing Specialist</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section10 -->
        <section class="section10 mt-5">
            <div class="container">
                <div class="row mb-3 mt-3 text-center">
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img src="assets/image/1 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/2 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/3 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/4 (1).png"></a>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>