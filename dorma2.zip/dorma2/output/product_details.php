<?php $page= "product";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- plus-minus-button -->    
<link href="assets/plus-minus-buttons/style.css" rel="stylesheet" type="text/css"> 
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">Product Details</h1>
                        <p class="mt-3 small">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">HOME</a> 
                            <span class="text-white small"> / &nbsp; Listing</span>
                        </p>
                    </div>
                </div>
            </div>
        </section><br>

        
        <!-- section3 -->
        <section class="text-center  white-bg text-md-left">
            <div class="p-lg-4 m-3">
                <div class="row bg-white p-md-5 p-3">
                    <div class="col-12 col-lg-6 left-reveal mt-lg-0 mt-5 pt-lg-0">
                        <div class="swiper-container gallery-top3">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger1 w-100" data-zoom="assets/image/book1.png" src="assets/image/book1.png">
                                    </div>
                                </div>

                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger2 w-100" data-zoom="assets/image/book2.png" src="assets/image/book2.png">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger3 w-100" data-zoom="assets/image/book3.png" src="assets/image/book3.png">
                                    </div>
                                </div>

                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger4 w-100" data-zoom="assets/image/book1.png" src="assets/image/book1.png">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger5 w-100" data-zoom="assets/image/book2.png" src="assets/image/book2.png">
                                    </div>
                                </div>

                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="drift-demo-trigger6 w-100" data-zoom="assets/image/book3.png" src="assets/image/book3.png">
                                    </div>
                                </div>
                            </div>
                            <!-- Add Arrows -->
                            <div class="swiper-button-next swiper-button-white bg-blue1" style="border-radius: 50px; padding: 25px;"></div>
                            <div class="swiper-button-prev swiper-button-white bg-blue1" style="border-radius: 50px; padding: 25px;"></div>
                        </div>

                        <div class="swiper-container gallery-thumbs3 mt-3">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide card">
                                    <div class="pt-4 w-100">
                                        <img class="w-100" src="assets/image/book1.png">
                                    </div>
                                </div>
                                <div class="swiper-slide card">
                                    <div class="pt-4">
                                        <img class="w-100" src="assets/image/book2.png">
                                    </div>
                                </div>
                                <div class="swiper-slide card">
                                    <div class="pt-4">
                                        <img class="w-100" src="assets/image/book3.png">
                                    </div>
                                </div>
                                <div class="swiper-slide card">
                                    <div class="pt-4">
                                        <img class="w-100" src="assets/image/book1.png">
                                    </div>
                                </div>
                                <div class="swiper-slide card">
                                    <div class="pt-4">
                                        <img class="w-100" src="assets/image/book2.png">
                                    </div>
                                </div>
                                <div class="swiper-slide card">
                                    <div class="pt-4">
                                        <img class="w-100" src="assets/image/book3.png">
                                    </div>
                                </div>
                            </div>
                            <!-- Add Arrows
                            <div class="swiper-button-next swiper-button-white bg-primary p-4 rounded-circle"></div>
                            <div class="swiper-button-prev swiper-button-white bg-primary p-4 rounded-circle"></div>
                            <!-- Add Scroll Bar
                            <div class="swiper-scrollbar"></div> -->
                        </div>
                    </div>

                    <div class="col-12 col-lg-6 text-left mt-lg-0 mt-5 pt-5 pt-lg-0">
                        <div class="detail w-100">
                            <div class="d-md-flex justify-content-between">
                                  <span>
                                      <p class="mb-0">kids patiala suit</p>
                                      <a class="card-link text-black h5 a3" href="#">Be the first to review | Have a question?</a>
                                  </span>
                                  <i class="fa fa-heart text-muted"></i>
                              </div>
                              <div class="row justify-content-between">
                                    <div class="col-md-6">
                                      <p class="mb-1 text-secondary">MRP  Rs. 3,500  (Inclusive of all taxes)</p>
                                      <h5 class="text-danger">Rs. 999</h5>
                                      <div>
                                          <i class="fa fa-star text-warning"></i><i class="fa fa-star text-warning ml-1"></i><i class="fa fa-star text-warning ml-1"></i><i class="fa fa-star text-warning ml-1"></i><i class="fa fa-star text-warning ml-1"></i>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                        <form class="form-inline form ml-md-0 my-3">
                                            <input class="input" type="number" min="1" max="100" value="1" />
                                        </form>
                                    </div>
                              </div>
                              
                              <div class="d-md-flex">
                                  <span>
                                      <p class="mt-2 text-secondary">Status:</p>
                                  </span>
                                  <span class="mt-2 ml-lg-5">
                                      <p class="text-green"><b>in stock</b></p>
                                  </span>
                              </div>

                            <p class="mt-3 text-secondary text-left mb-0"><b>Expires in</b></p>
                          
                            <div class="row text-center">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-lg-3 col-6 mt-2">
                                            <div class="card">
                                                <div class="card-body p-3">
                                                    <h4 class="text-danger h2 font-weight-bold count-this" data-text="">10</h4>
                                                </div>
                                            </div>
                                            <p class="mt-3 text-secondary"><b>Days</b></p>
                                        </div>
                                        <div class="col-lg-3 col-6 mt-2">
                                            <div class="card">
                                                <div class="card-body p-3">
                                                    <h4 class="text-danger h2 font-weight-bold count-this" data-text="">13</h4>
                                                </div>
                                            </div>
                                            <p class="mt-3 text-secondary"><b>hours</b></p>
                                        </div>
                                        <div class="col-lg-3 col-6 mt-2">
                                            <div class="card">
                                                <div class="card-body p-3">
                                                    <h4 class="text-danger h2 font-weight-bold count-this" data-text="">15</h4>
                                                </div>
                                            </div>
                                            <p class="mt-3 text-secondary"><b>minutes</b></p>
                                        </div>
                                        <div class="col-lg-3 col-6 mt-2">
                                            <div class="card">
                                                <div class="card-body p-3">
                                                    <h4 class="text-danger h2 font-weight-bold count-this" data-text="">37</h4>
                                                </div>
                                            </div>
                                            <p class="mt-3 text-secondary"><b>seconds</b></p>
                                        </div>
                                    </div>

                                    <div class="progress" style="height:20px">
                                        <div class="progress-bar bg-success" style="width:40%;height:20px"></div>
                                    </div>
                                    <p class="text-left mt-3 text-secondary"><b class="text-green">38/78</b> sold</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section1 -->
        <section class="section1 mt-md-5 mt-3 pt-4">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="">
                            <!-- Nav pills -->
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item left-reveal">
                                    <a class="nav-link active rounded-0 h px-5 py-3 h6 text-black1" data-toggle="pill" href="#home">DESCRIPTION</a>
                                </li>
                                <li class="nav-item left-reveal">
                                    <a class="nav-link px-5 rounded-0 h py-3 h6 text-black1" data-toggle="pill" href="#menu1">ADDITIONAL INFORMATION</a>
                                </li>
                                <li class="nav-item right-reveal">
                                    <a class="nav-link px-5 rounded-0 py-3 h6 text-black1" data-toggle="pill" href="#menu2">REVIEWS (0)</a>
                                </li>
                                
                            </ul>
                        </div>
                        
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active py-5" id="home">
                                <p class="mt-4">Donec at nunc et felis vehicula imperdiet. Aliquam ac nulla id purus lacinia imperdiet commodo sit amet nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aenean ultricies et risus in porta. Nam finibus, nisl ut sodales ultrices, libero urna condimentum tortor, a commodo tortor tortor a sem. Donec vehicula neque vel nisl malesuada blandis.</p>

                                <div class="">
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis ex mi, laoreet sed aliquet et, egestas non felis.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis commodo lobortis nisi at luctus.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis ex mi, laoreet sed aliquet et, egestas non felis.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis commodo lobortis nisi at luctus.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis ex mi, laoreet sed aliquet et, egestas non felis.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis commodo lobortis nisi at luctus.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis ex mi, laoreet sed aliquet et, egestas non felis.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis ex mi, laoreet sed aliquet et, egestas non felis.</p>
                                    <p class="mb-2"><i class="fa fa-check fa-lg mr-2 text-gold"></i> Duis commodo lobortis nisi at luctus.</p>
                                </div>
                                <p class="mt-3">In mattis scelerisque magna, ut tincidunt ex. Quisque nibh urna, pretium in tristique in, bibendum sed libero. Pellentesque mauris nunc, pretium non erat non, finibus tristique dui. Ut sed sem orci. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
                            </div>
                            <div class="tab-pane fade py-5" id="menu1">
                                <h6>WEIGHT</h6>
                                <p>1 kg</p>

                                <h6 class="mt-4">DIMENSIONS</h6>
                                <p>10 × 20 × 30 cm</p>
                            </div>
                            <div class="tab-pane fade py-5 mb-4 text-left" id="menu2">
                                <h5>1 REVIEW FOR CACTUS</h5>
                                <div class="media">
                                    <img class="w-25 mr-3" src="assets/image/2.jpg">
                                    <div class="media-body">
                                        <i class="fa fa-star text-body"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-grey1 ml-2"></i>

                                        <h6 class="mb-0">ELIZABETH DAVIS – <i class="p1 text-grey1">May 20, 2020</i></h6>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed aliquet ornare nulla!</p>
                                    </div>
                                </div>

                                <div class="mt-4">
                                    <h6 class="mb-0">ADD A REVIEW</h6>
                                    <p class="mb-0">Your email address will not be published. Required fields are marked *

                                        Your Rating</p>
                                    <div>
                                        <i class="fa fa-star text-body"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-body ml-2"></i>
                                        <i class="fa fa-star text-grey1 ml-2"></i>
                                    </div>    
                                </div>
                                <form class="mt-4" name="frmContact" id="frmContact" method="post" action="#" enctype="multipart/form-data">
                                    <div class="form-row mt-1 mb-4" data-aos="fade-up" data-aos-duration="1000">
                                        <div class="form-group col-12 mt-2">
                                            <label for="name">MESSAGE</label>
                                            <textarea name="txtMessage" id="txtMessage" class="form-control border border-muted p-2 rounded-0 shadow-none" rows="8"></textarea>
                                        </div>
                                        <div class="row">
                                            <div class="form-group col-md-6 mt-2">
                                                <label for="name">NAME</label>
                                                <div class="border border-muted rounded-0 p-1">
                                                    <input type="text" name="txtName" class="form-control border-0 shadow-none">
                                                </div>
                                            </div>
                                            <div class="form-group col-md-6 mt-2">
                                                <label for="name">EMAIL</label>
                                                <div class="border border-muted rounded-0 p-1">
                                                    <input type="email" name="txtName" class="form-control border-0 shadow-none">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group col-12 mt-2"></div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="customCheck" name="example1">
                                                <label class="custom-control-label" for="customCheck">
                                                    Save my name, email, and website in this browser for the next time I comment.</label>
                                            </div>
                                        </div>
                                        <div class="form-group col-12 pl-0 mt-2">
                                            <a href="#" class="btn btn btns8 px-5 mt-3 col-md-3 py-3 rounded-0">Submit</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section5 -->
        <section class="section5 mt-3 pb-4">
            <div class="container ">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">OUR FEATURES</h6>
                        <h2 class="left-reveal right-reveal">Find Your Perfect Teacher</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <!-- Swiper -->
                <div class="swiper-container py-4 swiper2">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="shadow-sm rounded-lg hvr-float-shadow">
                                <a href="#"><img class="w-100" src="assets/image/3.jpg"></a>
                                <div class="p-4">
                                    <a class="text-decoration-none text-hvr1" href="#"><h5 class="mb-0 font-weight-bold h6">Kesab Barun</h5></a>
                                    <small class="text-muted">Indian Clasic Vocal</small>
                                    <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                    <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="shadow-sm rounded-lg hvr-float-shadow">
                                <a href="#"><img class="w-100" src="assets/image/3.jpg"></a>
                                <div class="p-4">
                                    <a class="text-decoration-none text-hvr1" href="#"><h5 class="mb-0 font-weight-bold h6">Kesab Barun</h5></a>
                                    <small class="text-muted">Indian Clasic Vocal</small>
                                    <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                    <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="shadow-sm rounded-lg hvr-float-shadow">
                                <a href="#"><img class="w-100" src="assets/image/3.jpg"></a>
                                <div class="p-4">
                                    <a class="text-decoration-none text-hvr1" href="#"><h5 class="mb-0 font-weight-bold h6">Kesab Barun</h5></a>
                                    <small class="text-muted">Indian Clasic Vocal</small>
                                    <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                    <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                                </div>
                            </div>
                        </div>
                    </div><br><br><br>
                    <!-- Add Arrows -->
                    <div class="swiper-button-next swiper-button-white bg-blue1" style="border-radius: 50px; padding: 25px;"></div>
                    <div class="swiper-button-prev swiper-button-white bg-blue1" style="border-radius: 50px; padding: 25px;"></div>
                </div>
            </div>
        </section>



        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>
<!-- ALL-product-zoom-master -->
<script src="assets/ALL-product-zoom-master/jquery.zoom.js"></script>    

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

<script>
    var galleryThumbs = new Swiper('.gallery-thumbs3', {
      spaceBetween: 15,
      slidesPerView: 4,
      loop: true,
      freeMode: true,
      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      },
      freeMode: true,
      watchSlidesVisibility: true,
      watchSlidesProgress: true,
    });
    var galleryTop = new Swiper('.gallery-top3', {
      spaceBetween: 10,
      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      },
      thumbs: {
          swiper: galleryThumbs
      }
    });

    new Drift(document.querySelector('.drift-demo-trigger1'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });
    new Drift(document.querySelector('.drift-demo-trigger2'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });
    new Drift(document.querySelector('.drift-demo-trigger3'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });
    new Drift(document.querySelector('.drift-demo-trigger4'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });
    new Drift(document.querySelector('.drift-demo-trigger5'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });
    new Drift(document.querySelector('.drift-demo-trigger6'), {
        paneContainer: document.querySelector('.detail'),
        inlinePane: 900,
        inlineOffsetY: -85,
        containInline: true,
        hoverBoundingBox: true
    });

    //<!-- plus-minus-button -->    
    (function($) {
      $.fn.spinner = function() {
          this.each(function() {
              var el = $(this);

              // add elements
              el.wrap('<span class="spinner"></span>');     
              el.before('<span class="sub">-</span>');
              el.after('<span class="add">+</span>');

              // substract
              el.parent().on('click', '.sub', function () {
                  if (el.val() > parseInt(el.attr('min')))
                      el.val( function(i, oldval) { return --oldval; });
              });

              // increment
              el.parent().on('click', '.add', function () {
                  if (el.val() < parseInt(el.attr('max')))
                      el.val( function(i, oldval) { return ++oldval; });
              });
          });
      };
    })(jQuery);
    $('input[type=number]').spinner();


    // swiper-master    
    var swiper2 = new Swiper( '.swiper2', {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 1,

        autoplay: {
            delay: 5000,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            renderBullet: function (index, className) {
                return '<span class="' + className + '">' + (index + 1) + '</span>';
            },
        },

        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
            clickable: true,
        },
        
        // Responsive breakpoints
        breakpoints: {
            // when window width is <= 480px
            480: {
            slidesPerView: 1,
            spaceBetween: 20
            },
            // when window width is <= 640px
            768: {
            slidesPerView: 2,
            spaceBetween: 20
            },
            // when window width is <= 640px
            992: {
            slidesPerView: 3,
            spaceBetween: 20
            }
        },  
    } );
</script>

</body>
</html>