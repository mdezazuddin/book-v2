
	<nav class="navbar navbar-expand-md p-md-0 nav1">
		<div class="container">

			<a class="navbar-brand clr-red pt-2 d-flex" href="index.php">
				<img src="assets/image/logo.png">
				<span class="font-weight-bold h4 ml-1 clr1 text-whites align-self-center">Dorma</span>
			</a>
			<button class="navbar-toggler navbar-dark clr2" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link clr1 <?php if($page=="home"){echo "active-menu";} ?>" href="index.php">Home</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link clr1 <?php if($page=="about"){echo "active-menu";} ?>" href="about.php">About</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link clr1 <?php if($page=="product"){echo "active-menu";} ?>"
							href="product.php">Product</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link clr1 <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">Contact</a>
					</li>  
					<span class="pt-2"><a href="login.php" class="btn btn btns9 rounded-pill px-4 mt-2 ml-md-4">Login</a></span>
					<span class="pt-2"><a href="register.php" class="btn btn btns9 rounded-pill px-4 mt-2 ml-md-3">Register</a></span>
					<a href="#" class="text-white clr1 ml-3 mt-3 pt-1"><i class="fa fa-search fa-lg"></i></a>
				</ul>
			</div>  
		</div>
	</nav>